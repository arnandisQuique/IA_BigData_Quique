#!/bin/bash
echo "Iniciando infraestructura de Big Data..."

# 1. Levantar contenedores
docker compose up -d

# 2. Esperar un tiempo prudencial para que Kafka y HDFS estén listos
echo "Esperando a que los servicios inicialicen..."
sleep 30

# 3. (Opcional) Si necesitas crear los topics de Kafka automáticamente:
# docker exec kafka kafka-topics --create --topic crypto.ticker --bootstrap-server kafka:29092 --partitions 1 --replication-factor 1

echo "¡Pipeline desplegado! Puedes acceder a:"
echo "Grafana: http://localhost:3000"
echo "HDFS: http://localhost:9870"