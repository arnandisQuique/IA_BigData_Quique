import json, time, logging
import websocket
from kafka import KafkaProducer
from prometheus_client import Gauge, Counter, start_http_server


# --- PARCHE: Esperar a que Kafka despierte ---
print("Esperando 20 segundos a que Kafka arranque por completo...")
time.sleep(20)
# ---------------------------------------------


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("producer")

# ── Métricas Prometheus ──────────────────────────────────────
precio_actual  = Gauge("crypto_precio_actual", "Precio actual USD", ["par"])
volumen_24h    = Gauge("crypto_volumen_24h",   "Volumen 24h",        ["par"])
mensajes_total = Counter("pipeline_mensajes_total", "Mensajes enviados a Kafka")

# ── Kafka Producer ───────────────────────────────────────────
producer = KafkaProducer(
    bootstrap_servers="kafka:29092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    retries=5,
)

PARES = ["btcusdt", "ethusdt"]   # BTC obligatorio + libre elección
TOPIC_TICKER = "crypto.ticker"
TOPIC_KLINE  = "crypto.kline"

# ── Construir URL con múltiples streams ──────────────────────
def build_ws_url(pares):
    streams = []
    for par in pares:
        streams.append(f"{par}@miniTicker")
        streams.append(f"{par}@kline_1m")
    combined = "/".join(streams)
    return f"wss://stream.binance.com:9443/stream?streams={combined}"

# ── Callback: mensaje recibido ────────────────────────────────
def on_message(ws, raw):
    try:
        wrapper = json.loads(raw)
        stream  = wrapper.get("stream", "")
        data    = wrapper.get("data", {})

        if "miniTicker" in stream:
            handle_ticker(data)
        elif "kline" in stream:
            handle_kline(data)
    except Exception as e:
        logger.error(f"Error procesando mensaje: {e}")

def handle_ticker(data):
    if "s" not in data or "c" not in data:
        return

    try:
        # --- AQUÍ ESTABA EL FALLO: Actualizar Prometheus ---
        par_nombre = data.get("s")
        precio = float(data.get("c", 0.0))
        volumen = float(data.get("v", 0.0))

        # Actualizamos las métricas de Prometheus
        precio_actual.labels(par=par_nombre).set(precio)
        volumen_24h.labels(par=par_nombre).set(volumen)
        mensajes_total.inc()
        # ----------------------------------------------------

        mensaje = {
            "par": par_nombre,
            "precio": precio,
            "volumen": volumen,
            "cambio_pct": float(data.get("P", 0.0)),
            "timestamp": data.get("E", time.time() * 1000),
            "tipo": "ticker",
        }
        producer.send(TOPIC_TICKER, value=mensaje)
        producer.flush()
        logger.info(f"Enviado {mensaje['par']} a Kafka y actualizado Prometheus")
    except Exception as e:
        logger.error(f"Error: {e}")


def handle_kline(data):
    k = data["k"]
    mensaje = {
        "par":       k["s"],
        "open":     float(k["o"]),
        "high":     float(k["h"]),
        "low":      float(k["l"]),
        "close":    float(k["c"]),
        "volumen":  float(k["v"]),
        "cerrada":  k["x"],           # True si la vela está cerrada
        "timestamp": k["t"],
        "tipo":     "kline",
    }
    producer.send(TOPIC_KLINE, value=mensaje)
    mensajes_total.inc()

def on_error(ws, error):
    logger.error(f"WebSocket error: {error}")

def on_close(ws, *args):
    logger.warning("WebSocket cerrado. Reconectando en 5s...")

def on_open(ws):
    logger.info("WebSocket conectado a Binance")

if __name__ == "__main__":
    start_http_server(8000)        # expone métricas en :8000/metrics
    url = build_ws_url(PARES)

    while True:                      # bucle de reconexión automática
        ws = websocket.WebSocketApp(
            url,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            on_open=on_open,
        )
        ws.run_forever(ping_interval=30, ping_timeout=10)
        time.sleep(5)              # espera antes de reconectar