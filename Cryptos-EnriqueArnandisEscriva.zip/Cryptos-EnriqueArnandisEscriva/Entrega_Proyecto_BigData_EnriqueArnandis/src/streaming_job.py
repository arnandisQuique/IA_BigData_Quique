from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, from_json, window, avg, stddev,
    max as spark_max, min as spark_min,
    expr, to_timestamp, date_format, lit,
)
from pyspark.sql.types import (
    StructType, StructField, StringType,
    DoubleType, LongType, BooleanType,
)

# ── SparkSession ─────────────────────────────────────────────
# Cambia esta parte en tu streaming_job.py:
spark = (
    SparkSession.builder
    .appName("CryptoStreamingJob")
    .master("spark://spark-master:7077")
    # Asegúrate de usar la versión exacta de Kafka que tienes
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1") 
    .config("spark.hadoop.fs.defaultFS", "hdfs://namenode:9000") # Cambiado de 8020 a 9000
    .getOrCreate()
)
spark.sparkContext.setLogLevel("WARN")

# ── Schema del mensaje ticker ─────────────────────────────────
ticker_schema = StructType([
    StructField("par",        StringType()),
    StructField("precio",     DoubleType()),
    StructField("volumen",    DoubleType()),
    StructField("cambio_pct", DoubleType()),
    StructField("timestamp",  LongType()),
    StructField("tipo",       StringType()),
])

# ── Leer de Kafka ─────────────────────────────────────────────
raw_stream = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "kafka:29092")
    .option("subscribe", "crypto.ticker")
    .option("startingOffsets", "latest")
    .option("failOnDataLoss", "false")
    .load()
)

# ── Parsear JSON ──────────────────────────────────────────────
ticker_df = (
    raw_stream
    .select(from_json(col("value").cast("string"), ticker_schema).alias("d"))
    .select("d.*")
    .withColumn("event_time", to_timestamp(col("timestamp") / 1000))
    .withColumn("fecha", date_format("event_time", "yyyy-MM-dd"))
    .filter(col("precio").isNotNull())  # filtrar nulos
)

# ── INDICADOR 1: Media Móvil Simple (SMA 5 min) ──────────────
# Ventana 5 min, deslizamiento 30 seg
# Justificación: detecta tendencia sin demasiado ruido
sma_df = (
    ticker_df
    .withWatermark("event_time", "10 seconds")
    .groupBy(
        col("par"),
        col("fecha"),
        window("event_time", "1 minutes", "30 seconds"),
    )
    .agg(
        avg("precio").alias("sma_5m"),
        stddev("precio").alias("volatilidad"),
        spark_max("precio").alias("max_precio"),
        spark_min("precio").alias("min_precio"),
        avg("volumen").alias("avg_volumen"),
    )
    .withColumn("window_start", col("window.start"))
    .withColumn("window_end",   col("window.end"))
    .drop("window")
)

# ── INDICADOR 2: Detección Pump & Dump ───────────────────────
# Ventana 2 min, deslizamiento 30 seg
# Si precio sube/baja >3% en 2 min → anomalía
pump_df = (
    ticker_df
    .withWatermark("event_time", "30 seconds")
    .groupBy(col("par"), window("event_time", "2 minutes", "30 seconds"))
    .agg(
        spark_max("precio").alias("max_p"),
        spark_min("precio").alias("min_p"),
    )
    .withColumn("variacion_pct",
        ((col("max_p") - col("min_p")) / col("min_p")) * 100
    )
    .withColumn("pump_dump", col("variacion_pct") > lit(3.0))
)

# ── Salida 1: HDFS en formato Parquet ────────────────────────
# Cambia los hdfs://namenode:8020 por hdfs://namenode:9000
hdfs_query = (
    sma_df.writeStream
    .outputMode("append")
    .format("parquet")
    .option("path", "hdfs://namenode:9000/data/cripto")
    .option("checkpointLocation", "hdfs://namenode:9000/checkpoints/sma")
    .partitionBy("par", "fecha")
    .trigger(processingTime="30 seconds")
    .start()
)

# ── Salida 2: consola (debug) ─────────────────────────────────
debug_query = (
    pump_df.writeStream
    .outputMode("update")
    .format("console")
    .option("truncate", "false")
    .trigger(processingTime="30 seconds")
    .start()
)

spark.streams.awaitAnyTermination()