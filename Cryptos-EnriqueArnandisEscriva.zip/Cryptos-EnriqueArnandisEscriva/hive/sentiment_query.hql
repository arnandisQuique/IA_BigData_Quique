-- Tabla Fear & Greed
CREATE EXTERNAL TABLE IF NOT EXISTS fear_greed (
    valor         INT,
    clasificacion STRING,
    ts            TIMESTAMP
)
STORED AS PARQUET
LOCATION 'hdfs://namenode:8020/data/sentiment';

-- JOIN: volumen BTC vs índice de sentimiento
SELECT
    m.fecha,
    m.avg_volumen         AS volumen_btc,
    f.valor               AS fear_greed_idx,
    f.clasificacion
FROM crypto_metricas m
JOIN fear_greed f
  ON m.fecha = DATE(f.ts)
WHERE m.par = 'BTCUSDT'
ORDER BY m.fecha;