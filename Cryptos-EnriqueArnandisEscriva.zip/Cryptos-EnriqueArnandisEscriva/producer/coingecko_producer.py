import time, json, requests, logging
from kafka import KafkaProducer

logger = logging.getLogger("coingecko")

producer = KafkaProducer(
    bootstrap_servers="kafka:29092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
)

COINGECKO_URL = (
    "https://api.coingecko.com/api/v3/simple/price"
    "?ids=bitcoin,ethereum"
    "&vs_currencies=usd"
    "&include_market_cap=true"
    "&include_24hr_vol=true"
)

POLLING_INTERVAL = 60   # segundos — datos cambian lento

while True:
    try:
        resp = requests.get(COINGECKO_URL, timeout=10)
        data = resp.json()

        for coin_id, valores in data.items():
            mensaje = {
                "fuente":     "coingecko",
                "coin":       coin_id,
                "precio_usd": valores["usd"],
                "market_cap": valores["usd_market_cap"],
                "volumen_24h": valores["usd_24h_vol"],
                "timestamp":  int(time.time() * 1000),
            }
            producer.send("crypto.coingecko", value=mensaje)
            logger.info(f"CoinGecko {coin_id}: ${valores['usd']}")

    except Exception as e:
        logger.error(f"Error CoinGecko: {e}")

    time.sleep(POLLING_INTERVAL)