import time
import json
import requests
import logging
from kafka import KafkaProducer

# 1. Configurar el logger para poder usar logger.error y logger.info
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 2. Inicializar el productor
producer = KafkaProducer(
    bootstrap_servers="kafka:29092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8"),
)

# El índice se actualiza 1 vez al día -> polling horario es suficiente
POLLING_INTERVAL = 3600  # 1 hora en segundos

while True:
    try:
        resp = requests.get("https://api.alternative.me/fng/?limit=10", timeout=10)
        resp.raise_for_status() # Lanza un error si la respuesta no es 200 OK
        
        data = resp.json()["data"]
        
        for entry in data:
            mensaje = {
                "valor": int(entry["value"]),
                "clasificacion": entry["value_classification"],
                "timestamp": int(entry["timestamp"]) * 1000,
                "fuente": "fear_greed",
            }
            producer.send("crypto.sentiment", value=mensaje)
            
        # 3. Forzar el envío de los mensajes al broker
        producer.flush()
        logger.info("Datos de Fear&Greed enviados a Kafka correctamente.")

    except Exception as e:
        logger.error(f"Error Fear&Greed: {e}")
    
    # 4. Esperar antes de la siguiente iteración (fuera del try/except)
    time.sleep(POLLING_INTERVAL)