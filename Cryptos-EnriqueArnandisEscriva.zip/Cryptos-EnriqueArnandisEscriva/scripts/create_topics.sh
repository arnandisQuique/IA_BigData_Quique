#!/bin/bash
# Espera a que Kafka esté listo
echo "Esperando a Kafka..."
sleep 20

KAFKA_BIN="docker exec kafka /usr/bin/kafka-topics"
BROKER="kafka:29092"

# Topic para miniTicker (precio, volumen, % cambio)
$KAFKA_BIN --create \
  --bootstrap-server $BROKER \
  --topic crypto.ticker \
  --partitions 2 \
  --replication-factor 1 \
  --if-not-exists

# Topic para velas OHLCV 1 minuto
$KAFKA_BIN --create \
  --bootstrap-server $BROKER \
  --topic crypto.kline \
  --partitions 2 \
  --replication-factor 1 \
  --if-not-exists

# Topic para métricas procesadas (salida de Spark)
$KAFKA_BIN --create \
  --bootstrap-server $BROKER \
  --topic crypto.metrics \
  --partitions 2 \
  --replication-factor 1 \
  --if-not-exists

echo "Topics creados:"
$KAFKA_BIN --list --bootstrap-server $BROKER