#!/bin/bash
# Envía el job a Spark (ahora nativo como root)
docker exec spark-master spark-submit \
  --master spark://spark-master:7077 \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0 \
  --conf "spark.hadoop.fs.defaultFS=hdfs://namenode:8020" \
  --conf "spark.jars.ivy=/tmp/.ivy2" \
  /app/streaming_job.py